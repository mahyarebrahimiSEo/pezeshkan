import test from 'node:test';
import assert from 'node:assert/strict';
import {parseVital, formatMetric, sevenSegments} from '../src/model.mjs';
test('rejects untrusted or unusable API metric data',()=>{for(const value of [null,{}, {label:'',value:30,maximum:80}, {label:'ظرفیت',value:NaN,maximum:80}, {label:'ظرفیت',value:90,maximum:80}, {label:'ظرفیت',value:30,maximum:0}])assert.throws(()=>parseVital(value));});
test('accepts zero, preserves a real maximum, and ignores unknown fields',()=>{assert.deepEqual(parseVital({label:'ظرفیت امروز',value:0,maximum:80,entityId:'clinic-1',extra:true}),{label:'ظرفیت امروز',value:0,maximum:80,entityId:'clinic-1'});});
test('day metric uses English and night metric uses Persian numerals',()=>{assert.equal(formatMetric(30,'day'),'30');assert.equal(formatMetric(30,'dark'),'۳۰');assert.equal(formatMetric(0,'day'),'0');});
test('seven segment paths support variable length and all digits',()=>{assert.equal(sevenSegments('30').length,2);for(let i=0;i<10;i++)assert.ok(sevenSegments(String(i))[0].length>=2);assert.throws(()=>sevenSegments('NaN'));});
