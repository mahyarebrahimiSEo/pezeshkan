'use client';
import {createElement as h, useEffect, useId, useRef, useState} from 'react';
import {artwork} from './artwork.mjs';
import {formatMetric, parseVital, sevenSegments} from './model.mjs';
const points={a:'5,0 31,0 35,4 31,8 5,8 1,4',g:'5,33 31,33 35,37 31,41 5,41 1,37',d:'5,66 31,66 35,70 31,74 5,74 1,70',b:'33,7 37,11 37,31 33,35 29,31 29,11',c:'33,40 37,44 37,64 33,68 29,64 29,44',e:'3,40 7,44 7,64 3,68 -1,64 -1,44',f:'3,7 7,11 7,31 3,35 -1,31 -1,11'};
function digits(value){const items=sevenSegments(String(value)),scale=Math.min(1.25,112/(items.length*44));return h('g',{transform:`translate(${160-(items.length*44-7)*scale/2} 127) scale(${scale} .88)`,fill:'#164d5e'},items.map((segments,i)=>h('g',{key:i,transform:`translate(${i*44} 0)`},[...segments].map(s=>h('polygon',{key:s,points:points[s]})))));}
function scoped(source,id){return source.replace(/id="([^"]+)"/g,(_,name)=>`id="${id}-${name}"`).replace(/url\(#([^)]+)\)/g,(_,name)=>`url(#${id}-${name})`);}
export function VitalPanel({metric,theme='day',width=264,defaultOpen=true,status='ready',onOpenChange}) {
 const [open,setOpen]=useState(defaultOpen),prefix=useId().replace(/[^a-zA-Z0-9_-]/g,''),launcher=useRef(null);
 const mode=theme==='dark'?'dark':'day';let checked=null;try{if(metric)checked=parseVital(metric);}catch{}
 const ready=status==='ready'&&checked!==null;
 function change(next){setOpen(next);onOpenChange?.(next);if(!next)requestAnimationFrame(()=>launcher.current?.focus());}
 useEffect(()=>{if(!open)return;const escape=e=>{if(e.key==='Escape')change(false);};document.addEventListener('keydown',escape);return()=>document.removeEventListener('keydown',escape);},[open,onOpenChange]);
 const label=ready?checked.label:status==='loading'?'در حال دریافت اطلاعات':'اطلاعات در دسترس نیست';
 const formatted=ready?formatMetric(checked.value,mode):'—';
 return h('div',{className:'pez-vital',dir:'rtl',style:{'--vital-width':`${Math.max(160,Math.min(440,Number(width)||264))}px`}},
 h('button',{ref:launcher,type:'button',className:'pez-vital-launcher',hidden:open,'aria-controls':prefix,'aria-expanded':open,onClick:()=>change(true)},'ویتال'),
 open&&h('aside',{id:prefix,className:'pez-vital-panel','aria-label':'ویتال پزشکآن','aria-busy':status==='loading'},
 h('svg',{viewBox:'0 0 440 790',role:'img','aria-label':ready?`${checked.label}: ${formatted} از ${checked.maximum}`:label},
 h('g',{dangerouslySetInnerHTML:{__html:scoped(artwork[mode],prefix)}}),
 h('g',{transform:'translate(22 44.2) scale(.9)'},h('g',{transform:'translate(60 282)'},
 h('text',{x:160,y:112,textAnchor:'middle',fontFamily:'Tahoma',fontSize:17,fill:mode==='dark'?'#bed3dc':'#385965'},label),
 ready&&mode==='day'?digits(checked.value):h('text',{x:160,y:188,textAnchor:'middle',fontFamily:'Tahoma',fontSize:68,fill:mode==='dark'?'#67eee4':'#164d5e'},formatted),
 h('text',{x:160,y:226,textAnchor:'middle',fontFamily:'Tahoma',fontSize:17,fill:mode==='dark'?'#a9c4cf':'#446774'},ready?`از ${formatMetric(checked.maximum,'dark')}`:'')))),
 h('button',{type:'button',className:'pez-vital-close',onClick:()=>change(false),'aria-label':'بستن پنل ویتال'},'بستن'),
 h('span',{className:'pez-vital-sr','aria-live':'polite'},label)));
}
export function VitalRemote({endpoint='/api/vital/',...props}) {
 const [state,setState]=useState({status:'loading',metric:null});
 useEffect(()=>{const controller=new AbortController();setState({status:'loading',metric:null});fetch(endpoint,{signal:controller.signal,credentials:'same-origin',headers:{Accept:'application/json'}}).then(async response=>{if(!response.ok)throw new Error('Request failed');return parseVital(await response.json());}).then(metric=>{if(!controller.signal.aborted)setState({status:'ready',metric});}).catch(()=>{if(!controller.signal.aborted)setState({status:'error',metric:null});});return()=>controller.abort();},[endpoint]);
 return h(VitalPanel,{...props,...state});
}
