export function parseVital(data) {
  if (!data || typeof data !== 'object' || typeof data.label !== 'string' || !data.label.trim() || data.label.length > 100 || !Number.isInteger(data.value) || data.value < 0 || !Number.isInteger(data.maximum) || data.maximum <= 0 || data.value > data.maximum) throw new Error('Invalid Vital metric');
  if(data.entityId !== undefined && (typeof data.entityId !== 'string' || data.entityId.length > 128)) throw new Error('Invalid entity');
  return {label:data.label.trim(), value:data.value, maximum:data.maximum, ...(data.entityId !== undefined ? {entityId:data.entityId} : {})};
}
export function formatMetric(value, theme) {return theme === 'dark' ? String(value).replace(/\d/g, d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]) : String(value);}
export function sevenSegments(value) {const digits=['abcdef','bc','abged','abgcd','fgbc','afgcd','afgecd','abc','abcdefg','abfgcd'];if(!/^\d+$/.test(value))throw new Error('Digits required');return [...value].map(d=>digits[Number(d)]);}
