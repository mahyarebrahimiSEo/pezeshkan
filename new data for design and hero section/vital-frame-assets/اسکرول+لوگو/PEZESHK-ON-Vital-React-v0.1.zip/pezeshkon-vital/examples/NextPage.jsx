'use client';
import {useState} from 'react';
import {VitalPanel} from '@pezeshkon/vital';
import '@pezeshkon/vital/styles.css';
export default function VitalExample(){const [theme,setTheme]=useState('day');return <main dir="rtl"><button onClick={()=>setTheme(theme==='day'?'dark':'day')}>تغییر روز و شب</button><VitalPanel theme={theme} metric={{label:'ظرفیت امروز',value:30,maximum:80,entityId:'demo'}} /></main>;}
