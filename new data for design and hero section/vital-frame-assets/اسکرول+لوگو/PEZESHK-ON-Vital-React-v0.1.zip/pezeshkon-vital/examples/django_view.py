"""Adapter example: configure a permission-aware application service first."""
from django.conf import settings
from django.http import JsonResponse
from django.utils.module_loading import import_string
from django.views.decorators.http import require_GET
from django.views.decorators.cache import never_cache

@require_GET
@never_cache
def vital(request):
    if not request.user.is_authenticated:
        return JsonResponse({"detail": "Authentication required"}, status=401)
    # Provider must resolve the user's clinic and enforce entity permissions.
    provider = import_string(settings.VITAL_METRIC_PROVIDER)
    payload = provider(request.user)
    return JsonResponse(payload)
